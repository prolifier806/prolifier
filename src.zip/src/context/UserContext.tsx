import { createContext, useContext, useEffect, useState, ReactNode } from "react";
import { User, Session } from "@supabase/supabase-js";
import { supabase } from "@/lib/supabase";

export type CurrentUser = {
  id: string;
  email: string;
  name: string;
  avatar: string;
  color: string;
  location: string;
  bio: string;
  project: string;
  skills: string[];
  lookingFor: string[];
  github: string;
  website: string;
  twitter: string;
  primaryLang: string;
  openToCollab: boolean;
  profileSetupDone: boolean;
};

const DEFAULT_USER: CurrentUser = {
  id: "",
  email: "",
  name: "",
  avatar: "",
  color: "bg-primary",
  location: "",
  bio: "",
  project: "",
  skills: [],
  lookingFor: [],
  github: "",
  website: "",
  twitter: "",
  primaryLang: "en",
  openToCollab: true,
  profileSetupDone: false,
};

interface UserContextValue {
  user: CurrentUser;
  session: Session | null;
  authUser: User | null;
  loading: boolean;
  profileComplete: boolean;
  updateUser: (patch: Partial<CurrentUser>) => Promise<void>;
  completeProfileSetup: () => Promise<void>;
  signOut: () => Promise<void>;
}

const UserContext = createContext<UserContextValue>({
  user: DEFAULT_USER,
  session: null,
  authUser: null,
  loading: true,
  profileComplete: false,
  updateUser: async () => {},
  completeProfileSetup: async () => {},
  signOut: async () => {},
});

const COLORS = [
  "bg-primary", "bg-accent", "bg-emerald-600", "bg-violet-600",
  "bg-sky-500", "bg-rose-500", "bg-amber-500", "bg-teal-600",
];

function randomColor() {
  return COLORS[Math.floor(Math.random() * COLORS.length)];
}

export function UserProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<CurrentUser>(DEFAULT_USER);
  const [session, setSession] = useState<Session | null>(null);
  const [authUser, setAuthUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  const CACHE_KEY = (id: string) => `prolifier_profile_${id}`;

  const profileFromRow = (userId: string, email: string, profile: any): CurrentUser => ({
    id: userId,
    email,
    name: profile.name || "",
    avatar: profile.avatar || "",
    color: profile.color || "bg-primary",
    location: profile.location || "",
    bio: profile.bio || "",
    project: profile.project || "",
    skills: profile.skills || [],
    lookingFor: profile.looking_for || [],
    github: profile.github || "",
    website: profile.website || "",
    twitter: profile.twitter || "",
    primaryLang: profile.primary_lang || "en",
    openToCollab: profile.open_to_collab ?? true,
    profileSetupDone: profile.profile_complete ?? false,
  });

  const loadProfile = async (userId: string, email: string) => {
    // Show cached profile instantly so the app feels fast, then update from DB.
    const cached = localStorage.getItem(CACHE_KEY(userId));
    if (cached) {
      try { setUser(JSON.parse(cached)); } catch { /* ignore corrupt cache */ }
    }

    try {
      const { data: profile } = await supabase
        .from("profiles")
        .select("*")
        .eq("id", userId)
        .single() as any;

      if (profile) {
        const next = profileFromRow(userId, email, profile);
        setUser(next);
        localStorage.setItem(CACHE_KEY(userId), JSON.stringify(next));
      } else {
        const next: CurrentUser = {
          ...DEFAULT_USER,
          id: userId,
          email,
          name: email.split("@")[0],
          avatar: email.slice(0, 2).toUpperCase(),
          color: randomColor(),
          profileSetupDone: false,
        };
        setUser(next);
        localStorage.setItem(CACHE_KEY(userId), JSON.stringify(next));
      }
    } catch {
      if (!cached) setUser({ ...DEFAULT_USER, id: userId, email });
    }
  };

  useEffect(() => {
    // onAuthStateChange is the single source of truth.
    // It always fires INITIAL_SESSION first — even before getSession() resolves —
    // which means it correctly catches the #access_token hash from email
    // confirmation links before anything else runs.
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      async (event, session) => {

        setSession(session);
        setAuthUser(session?.user ?? null);

        if (session?.user) {
          // Hold loading=true while the profile is being fetched so that
          // AuthRoute never evaluates with session=valid but a stale
          // profileComplete=false (DEFAULT_USER). This matters on SIGNED_IN
          // events where loading was already false from a prior
          // INITIAL_SESSION(null) (e.g. after email confirmation or login).
          setLoading(true);
          await loadProfile(session.user.id, session.user.email ?? "");
        } else {
          setUser(DEFAULT_USER);
        }

        setLoading(false);
      }
    );

    return () => subscription.unsubscribe();
  }, []);

  const updateUser = async (patch: Partial<CurrentUser>) => {
    if (!authUser) return;
    const next = { ...user, ...patch };
    setUser(next);
    localStorage.setItem(CACHE_KEY(authUser.id), JSON.stringify(next));
    await (supabase.from("profiles") as any).upsert({
      id: authUser.id,
      name: next.name,
      avatar: next.avatar,
      color: next.color,
      location: next.location,
      bio: next.bio,
      project: next.project,
      skills: next.skills,
      looking_for: next.lookingFor,
      github: next.github,
      website: next.website,
      twitter: next.twitter,
      primary_lang: next.primaryLang,
      open_to_collab: next.openToCollab,
      updated_at: new Date().toISOString(),
    });
  };

  const completeProfileSetup = async () => {
    if (!authUser) return;
    await (supabase.from("profiles") as any)
      .update({
        profile_complete: true,
        updated_at: new Date().toISOString(),
      })
      .eq("id", authUser.id);
    setUser(prev => {
      const next = { ...prev, profileSetupDone: true };
      localStorage.setItem(CACHE_KEY(authUser.id), JSON.stringify(next));
      return next;
    });
  };

  const signOut = async () => {
    if (authUser) localStorage.removeItem(CACHE_KEY(authUser.id));
    await supabase.auth.signOut();
    setUser(DEFAULT_USER);
    setSession(null);
    setAuthUser(null);
  };

  const profileComplete = user.profileSetupDone;

  return (
    <UserContext.Provider value={{
      user,
      session,
      authUser,
      loading,
      profileComplete,
      updateUser,
      completeProfileSetup,
      signOut,
    }}>
      {children}
    </UserContext.Provider>
  );
}

export const useUser = () => useContext(UserContext);