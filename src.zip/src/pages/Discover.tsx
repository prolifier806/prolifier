import { useState, useEffect, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { Search, MapPin, UserPlus, Check } from "lucide-react";
import Layout from "@/components/Layout";
import { toast } from "@/hooks/use-toast";
import { useUser } from "@/context/UserContext";
import { supabase } from "@/lib/supabase";
// ── Notification helper with prefs check ─────────────────────────────────
const createNotification = async (opts: { userId: string; type: string; text: string; subtext?: string; action?: string }) => {
  if (!opts.userId) return;
  // Check sender's own prefs (recipient prefs are checked on their side via realtime)
  const TYPE_PREF_MAP: Record<string, string> = {
    like: "likes", comment: "comments", match: "matches",
    collab: "collabs", group: "groups", message: "messages",
    trending: "trending",
  };
  const prefKey = TYPE_PREF_MAP[opts.type];
  if (prefKey) {
    try {
      const saved = localStorage.getItem("notif_prefs");
      const prefs = saved ? JSON.parse(saved) : {};
      // If the pref exists and is explicitly false, skip
      if (prefs[prefKey] === false) return;
    } catch {}
  }
  const { error } = await (supabase as any).from("notifications").insert({
    user_id: opts.userId, type: opts.type, text: opts.text,
    subtext: opts.subtext || null, action: opts.action || null, read: false,
  });
  if (error) console.error("createNotification:", error);
};


type Profile = {
  id: string;
  name: string;
  avatar: string;
  color: string;
  location: string;
  bio: string;
  project: string;
  skills: string[];
  openToCollab: boolean;
};

function DiscoverSkeleton() {
  return (
    <div className="grid gap-4 sm:grid-cols-2">
      {[1,2,3,4].map(i => (
        <div key={i} className="p-5 rounded-xl border border-border bg-card animate-pulse">
          <div className="flex items-start gap-3 mb-3">
            <div className="h-12 w-12 rounded-full bg-muted shrink-0" />
            <div className="flex-1 space-y-2 pt-1">
              <div className="h-3 bg-muted rounded w-28" />
              <div className="h-2.5 bg-muted rounded w-20" />
            </div>
          </div>
          <div className="space-y-2 mb-3">
            <div className="h-2.5 bg-muted rounded w-full" />
            <div className="h-2.5 bg-muted rounded w-3/4" />
          </div>
          <div className="flex gap-2 mb-3">
            <div className="h-5 bg-muted rounded-full w-16" />
            <div className="h-5 bg-muted rounded-full w-14" />
            <div className="h-5 bg-muted rounded-full w-20" />
          </div>
          <div className="flex justify-end">
            <div className="h-7 bg-muted rounded-lg w-24" />
          </div>
        </div>
      ))}
    </div>
  );
}

export default function Discover() {
  const { user } = useUser();
  const navigate = useNavigate();
  const [profiles, setProfiles] = useState<Profile[]>([]);
  const [connected, setConnected] = useState<Set<string>>(new Set());
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [collabOnly, setCollabOnly] = useState(false);

  const fetchProfiles = useCallback(async () => {
    setLoading(true);
    try {
      // Fetch all profiles except current user
      const { data, error } = await (supabase as any)
        .from("profiles")
        .select("id, name, avatar, color, location, bio, project, skills, open_to_collab")
        .neq("id", user.id)
        .not("name", "eq", "")
        .order("created_at", { ascending: false })
        .limit(50);

      if (error) throw error;

      setProfiles((data || []).map((p: any) => ({
        id: p.id,
        name: p.name || "Unknown",
        avatar: p.avatar || "?",
        color: p.color || "bg-primary",
        location: p.location || "",
        bio: p.bio || "",
        project: p.project || "",
        skills: p.skills || [],
        openToCollab: p.open_to_collab ?? true,
      })));

      // Fetch existing connections
      const { data: conns } = await (supabase as any)
        .from("connections")
        .select("receiver_id")
        .eq("requester_id", user.id);

      if (conns) {
        setConnected(new Set(conns.map((c: any) => c.receiver_id)));
      }
    } catch (err: any) {
      toast({ title: "Failed to load profiles", description: err.message, variant: "destructive" });
    } finally {
      setLoading(false);
    }
  }, [user.id]);

  useEffect(() => {
    if (user.id) fetchProfiles();
  }, [user.id, fetchProfiles]);

  const handleConnect = async (id: string, name: string) => {
    const isConnected = connected.has(id);

    // Optimistic update
    setConnected(prev => {
      const next = new Set(prev);
      isConnected ? next.delete(id) : next.add(id);
      return next;
    });

    if (isConnected) {
      await (supabase as any)
        .from("connections")
        .delete()
        .eq("requester_id", user.id)
        .eq("receiver_id", id);
      toast({ title: "Connection removed", description: `You disconnected from ${name}.` });
    } else {
      await (supabase as any)
        .from("connections")
        .insert({ requester_id: user.id, receiver_id: id, status: "pending" });
      toast({ title: "Connection request sent! 🤝", description: `${name} will be notified.` });
      createNotification({
        userId: id,
        type: "match",
        text: `${user.name} sent you a connection request`,
        subtext: user.bio?.slice(0, 60) || undefined,
        action: `profile:${user.id}`,
      });
    }
  };

  const filtered = profiles.filter(p => {
    const q = search.toLowerCase();
    const matchesSearch = !search ||
      p.name.toLowerCase().includes(q) ||
      p.project.toLowerCase().includes(q) ||
      p.bio.toLowerCase().includes(q) ||
      p.skills.some(s => s.toLowerCase().includes(q)) ||
      p.location.toLowerCase().includes(q);
    const matchesCollab = !collabOnly || p.openToCollab;
    return matchesSearch && matchesCollab;
  });

  return (
    <Layout>
      <div className="max-w-3xl mx-auto px-4 py-6">
        <h1 className="font-display text-2xl font-bold mb-6">Discover Builders</h1>

        <div className="flex gap-3 mb-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search by name, skill, project..."
              value={search}
              onChange={e => setSearch(e.target.value)}
              className="pl-10 h-11"
            />
          </div>
        </div>

        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-2">
            <Switch checked={collabOnly} onCheckedChange={setCollabOnly} />
            <span className="text-sm text-muted-foreground">Open to collaborate only</span>
          </div>
          <span className="text-xs text-muted-foreground">
            {loading ? "Loading..." : `${filtered.length} builder${filtered.length !== 1 ? "s" : ""}`}
          </span>
        </div>

        {loading ? (
          <DiscoverSkeleton />
        ) : filtered.length === 0 ? (
          <div className="text-center py-14 text-muted-foreground">
            <p className="text-sm font-medium mb-1">
              {profiles.length === 0 ? "No other builders yet" : "No builders found"}
            </p>
            <p className="text-xs mb-3">
              {profiles.length === 0
                ? "Invite friends to join Prolifier!"
                : "Try adjusting your search or filters."}
            </p>
            {profiles.length > 0 && (
              <button className="text-xs text-primary hover:underline"
                onClick={() => { setSearch(""); setCollabOnly(false); }}>
                Clear filters
              </button>
            )}
          </div>
        ) : (
          <div className="grid gap-4 sm:grid-cols-2">
            {filtered.map((p, i) => {
              const isConnected = connected.has(p.id);
              return (
                <motion.div
                  key={p.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.04 }}
                  className="p-5 rounded-xl border border-border bg-card hover:shadow-md transition-shadow"
                >
                  <div className="flex items-start gap-3 mb-3">
                    <button
                      onClick={() => navigate(`/profile/${p.id}`)}
                      className={`h-12 w-12 rounded-full ${p.color} flex items-center justify-center text-white font-semibold shrink-0 hover:opacity-80 transition-opacity`}
                    >
                      {p.avatar}
                    </button>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <button
                          onClick={() => navigate(`/profile/${p.id}`)}
                          className="font-semibold text-foreground hover:underline text-left text-sm"
                        >
                          {p.name}
                        </button>
                        {p.openToCollab && (
                          <span className="inline-flex items-center gap-1 text-xs text-emerald-600 font-medium">
                            <span className="h-1.5 w-1.5 rounded-full bg-emerald-500 inline-block" />
                            Open to collab
                          </span>
                        )}
                      </div>
                      {p.location && (
                        <p className="text-xs text-muted-foreground flex items-center gap-1 mt-0.5">
                          <MapPin className="h-3 w-3 shrink-0" /> {p.location}
                        </p>
                      )}
                    </div>
                  </div>

                  {p.bio && <p className="text-sm text-foreground mb-2 leading-relaxed line-clamp-2">{p.bio}</p>}
                  {p.project && (
                    <p className="text-xs text-muted-foreground mb-2">
                      Building: <span className="text-primary font-medium">{p.project}</span>
                    </p>
                  )}

                  {p.skills.length > 0 && (
                    <div className="flex flex-wrap gap-1.5 mb-3">
                      {p.skills.slice(0, 4).map(s => (
                        <Badge key={s} variant="outline" className="text-xs">{s}</Badge>
                      ))}
                      {p.skills.length > 4 && (
                        <Badge variant="outline" className="text-xs text-muted-foreground">+{p.skills.length - 4}</Badge>
                      )}
                    </div>
                  )}

                  <div className="flex items-center gap-2 justify-end">
                    <Button
                      size="sm"
                      variant="outline"
                      className="gap-1.5 text-xs h-7 px-3"
                      onClick={() => navigate(`/profile/${p.id}`)}
                    >
                      View profile
                    </Button>
                    <Button
                      size="sm"
                      variant={isConnected ? "outline" : "default"}
                      className={`gap-1.5 text-xs h-7 px-3 ${isConnected ? "border-primary text-primary" : ""}`}
                      onClick={() => handleConnect(p.id, p.name)}
                    >
                      {isConnected ? <Check className="h-3 w-3" /> : <UserPlus className="h-3 w-3" />}
                      {isConnected ? "Connected" : "Connect"}
                    </Button>
                  </div>
                </motion.div>
              );
            })}
          </div>
        )}
      </div>
    </Layout>
  );
}